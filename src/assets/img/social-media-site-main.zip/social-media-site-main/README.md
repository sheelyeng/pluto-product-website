# MERN Stack Social Media Site with Realtime updates

This is a bare-bone social media site where you can, Creat / Like / Comment / Share a Post, have friends, Message / Search other Users. 
User gets updated with all events in Realtime without any delay using Socket.io and Redis.

A page gets updated using socket if a user/friend gets online/offline or any post have new updates (likes/comments).

The site is built with REACT, NODEJS, EXPRESS, MONGODB, SOCKET.IO, REDIS.

You can check out the site here: [https://social-media-site-react.vercel.app/](https://social-media-site-react.vercel.app/)


Demo Accounts:

Email: demo1@mail.com   Password: hello123

Email: demo2@mail.com   Password: hello323

Email: jownsnow@gmail.com   Password: passw0rd

Email: abdulrehman@gmail.com   Password: passw0rd

